package com.example.fakehealth;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

public class FakeHealthMod implements ClientModInitializer {
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (mc.player != null) {
                PlayerEntity player = mc.player;
                player.setHealth(20.0F); // Keep HUD at full health
            }
        });
    }
}
